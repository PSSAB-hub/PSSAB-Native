package id.pssab.tanjunguncang

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/** Thin REST client using the same Supabase project as the supplied web app. */
class SupabaseApi {
    private val baseUrl = BuildConfig.SUPABASE_URL.trimEnd('/')
    private val anonKey = BuildConfig.SUPABASE_ANON_KEY
    private val client = OkHttpClient()
    @Volatile var accessToken: String? = null
    @Volatile var userId: String? = null
    @Volatile var userEmail: String? = null
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private fun request(path: String, method: String = "GET", body: String? = null, extra: Map<String,String> = emptyMap()): String {
        val b = Request.Builder().url("$baseUrl/$path")
            .header("apikey", anonKey)
            .header("Authorization", "Bearer ${accessToken ?: anonKey}")
            .header("Accept", "application/json")
        extra.forEach { (k,v) -> b.header(k,v) }
        when(method) {
            "POST" -> b.post((body ?: "{}").toRequestBody(jsonType))
            "PATCH" -> b.patch((body ?: "{}").toRequestBody(jsonType))
            "DELETE" -> b.delete((body ?: "").toRequestBody(jsonType))
            else -> b.get()
        }
        client.newCall(b.build()).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = runCatching { JSONObject(text).optString("message", JSONObject(text).optString("msg", text)) }.getOrDefault(text)
                throw IOException("HTTP ${response.code}: $message")
            }
            return text
        }
    }

    fun login(email: String, password: String): JSONObject {
        val result = JSONObject(request("auth/v1/token?grant_type=password", "POST", JSONObject().put("email",email).put("password",password).toString()))
        accessToken = result.optString("access_token").takeIf { it.isNotBlank() }
        userId = result.optJSONObject("user")?.optString("id")
        userEmail = result.optJSONObject("user")?.optString("email")
        if (accessToken.isNullOrBlank() || userId.isNullOrBlank()) throw IOException("Respons login tidak lengkap.")
        return profile()
    }
    fun logout() { accessToken = null; userId = null; userEmail = null }
    fun profile(): JSONObject = array("profiles?select=*&id=eq.${userId}&limit=1").optJSONObject(0)
        ?: throw IOException("Akun belum memiliki profil anggota di tabel profiles.")
    fun array(path: String): JSONArray = JSONArray(request("rest/v1/$path"))
    fun insert(table: String, data: JSONObject): String = request("rest/v1/$table", "POST", data.toString(), mapOf("Prefer" to "return=representation"))
    fun update(table: String, filter: String, data: JSONObject): String = request("rest/v1/$table?$filter", "PATCH", data.toString(), mapOf("Prefer" to "return=representation"))
    fun rpc(name: String, data: JSONObject): String = request("rest/v1/rpc/$name", "POST", data.toString())
    fun resetPassword(email: String) { request("auth/v1/recover", "POST", JSONObject().put("email",email).toString(), mapOf("Authorization" to "Bearer $anonKey")) }
    fun createMember(name: String, phone: String, email: String, password: String, role: String, groupCode: String) {
        val meta = JSONObject().put("name", name).put("phone", phone).put("bona_group_code", groupCode)
            .put("relationship", mapOf("01" to "Bona", "02" to "Boru", "03" to "Bere", "04" to "Iba Bere")[groupCode] ?: "Bona")
        val created = JSONObject(request("auth/v1/signup", "POST", JSONObject().put("email", email).put("password", password).put("data", meta).toString(), mapOf("Authorization" to "Bearer $anonKey")))
        val newUserId = created.optJSONObject("user")?.optString("id").orEmpty()
        if (newUserId.isBlank()) throw IOException("Akun anggota tidak berhasil dibuat. Periksa pengaturan konfirmasi email Supabase.")
        val result = request("rest/v1/rpc/admin_create_member", "POST", JSONObject().put("p_user_id", newUserId).put("p_name", name).put("p_phone", phone).put("p_bona_group_code", groupCode).put("p_role", role).toString())
        if (result.contains("\"error\"")) throw IOException(result)
    }
    fun updateMember(id: String, name: String, phone: String, role: String, active: Boolean) {
        val result = request("rest/v1/rpc/admin_update_member", "POST", JSONObject().put("p_user_id", id).put("p_name", name).put("p_phone", phone).put("p_role", role).put("p_active", active).toString())
        if (result.contains("\"error\"")) throw IOException(result)
    }
    fun deleteMember(id: String) {
        val result = request("rest/v1/rpc/admin_delete_member", "POST", JSONObject().put("p_user_id", id).toString())
        if (result.contains("\"error\"")) throw IOException(result)
    }
    fun members(): JSONArray = array("profiles?select=*&order=name.asc")
    fun schedules(): JSONArray = array("schedules?select=*&order=event_date.asc")
    fun messages(): JSONArray = array("messages?select=id,text,created_at,sender_id,profiles(name,role)&order=created_at.asc")
    fun attendance(): JSONArray = array("attendance?select=*")
    fun documentation(): JSONArray = array("documentation?select=id,image_url,caption,created_at,uploader_id,profiles(name)&order=created_at.desc")
    fun sendMessage(text: String) { insert("messages", JSONObject().put("sender_id", userId).put("text",text)) }
    fun addSchedule(title: String, date: String, time: String, location: String) { insert("schedules", JSONObject().put("title",title).put("event_date",date).put("event_time",time).put("location",location)) }
    fun markAttendance(scheduleId: String, memberId: String) {
        request("rest/v1/attendance?on_conflict=schedule_id,member_id", "POST", JSONObject().put("schedule_id",scheduleId).put("member_id",memberId).put("status","Hadir").toString(), mapOf("Prefer" to "resolution=merge-duplicates,return=representation"))
    }
}
