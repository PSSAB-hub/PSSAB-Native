package id.pssab.tanjunguncang

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private val Maroon = Color(0xFF8E0714)
private val DeepRed = Color(0xFF4D080C)
private val Gold = Color(0xFFE8BD5C)
private val Cream = Color(0xFFFFF7E9)
private val Ink = Color(0xFF182B43)

class MainActivity : ComponentActivity() {
    private val api = SupabaseApi()
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { PssabApp(api) } }
    fun openMaps(location: String) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(location)}"))) }
}

@Composable fun PssabApp(api: SupabaseApi) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val openMaps: (String) -> Unit = { location -> if (location.isNotBlank()) context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(location)}"))) }
    var profile by remember { mutableStateOf<JSONObject?>(null) }
    var page by remember { mutableStateOf("Beranda") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var members by remember { mutableStateOf(JSONArray()) }
    var schedules by remember { mutableStateOf(JSONArray()) }
    var chats by remember { mutableStateOf(JSONArray()) }
    var attendance by remember { mutableStateOf(JSONArray()) }
    var docs by remember { mutableStateOf(JSONArray()) }
    fun loadData() { scope.launch { busy=true; message=""; try { val d=withContext(Dispatchers.IO) { listOf(api.members(),api.schedules(),api.messages(),api.attendance(),api.documentation()) }; members=d[0];schedules=d[1];chats=d[2];attendance=d[3];docs=d[4] } catch(e:Exception) { message=e.message ?: "Gagal memuat data" } finally { busy=false } } }
    MaterialTheme(colorScheme = lightColorScheme(primary=Maroon, secondary=Gold, background=Cream, surface=Color.White)) {
        if (profile == null) {
            Box(Modifier.fillMaxSize().background(DeepRed).padding(22.dp), contentAlignment=Alignment.Center) {
                Column(Modifier.fillMaxWidth().background(Cream, RoundedCornerShape(24.dp)).padding(22.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(12.dp)) {
                    Image(androidx.compose.ui.res.painterResource(R.drawable.pssab_logo), null, Modifier.size(112.dp))
                    Text("PSSAB", fontSize=30.sp, fontWeight=FontWeight.Black, color=Maroon)
                    Text("HORAS JALA GABE PUNGUAN SITUMORANG SIPITU AMA · SEKTOR TANJUNG UNCANG", color=Ink, fontSize=12.sp)
                    OutlinedTextField(email,{email=it},label={Text("Email anggota")},singleLine=true,modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(password,{password=it},label={Text("Password")},visualTransformation=PasswordVisualTransformation(),singleLine=true,modifier=Modifier.fillMaxWidth())
                    Button(onClick={ if(email.isBlank()||password.isBlank()) {message="Isi email dan password."} else scope.launch {busy=true;message="";try { profile=withContext(Dispatchers.IO){api.login(email.trim(),password)};loadData() } catch(e:Exception){message=e.message ?: "Login gagal"}finally{busy=false} } }, modifier=Modifier.fillMaxWidth(), enabled=!busy) { Text(if(busy) "Memproses…" else "Masuk") }
                    TextButton(onClick={ if(email.isBlank()) message="Masukkan email terlebih dahulu." else scope.launch {busy=true;try {withContext(Dispatchers.IO){api.resetPassword(email.trim())};message="Jika akun terdaftar, tautan reset dikirim melalui email."}catch(e:Exception){message=e.message ?: "Gagal meminta reset password"}finally{busy=false}} }) { Text("Lupa password?") }
                    if(message.isNotBlank()) Text(message,color=Maroon,fontSize=12.sp)
                }
            }
        } else {
            Scaffold(containerColor=Cream, topBar={ TopAppBarPssab(page, profile?.optString("name").orEmpty()) }, bottomBar={ NavigationBar(containerColor=Color.White) {
                listOf("Beranda" to Icons.Default.Home,"Anggota" to Icons.Default.People,"Ibadah" to Icons.Default.Event,"Chat" to Icons.Default.Chat,"Profil" to Icons.Default.Person).forEach { (label,icon) -> NavigationBarItem(selected=page==label,onClick={page=label},icon={Icon(icon,null)},label={Text(label,fontSize=10.sp)}) }
            } }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=14.dp)) {
                    if(message.isNotBlank()) Text(message,color=Maroon,fontSize=12.sp,modifier=Modifier.padding(4.dp))
                    when(page) {
                        "Beranda" -> HomePage(profile!!,schedules,members,onNavigate={page=it},onRefresh={loadData()},onMaps=openMaps)
                        "Anggota" -> MembersPage(members, onRefresh={loadData()})
                        "Ibadah" -> SchedulePage(schedules,profile!!,onAdd={title,date,time,loc -> scope.launch {busy=true;try{withContext(Dispatchers.IO){api.addSchedule(title,date,time,loc)};message="Jadwal berhasil ditambahkan";loadData()}catch(e:Exception){message=e.message?:"Gagal menyimpan jadwal"}finally{busy=false}}},onAttend={id -> scope.launch {try{withContext(Dispatchers.IO){api.markAttendance(id,api.userId!!)};message="Presensi berhasil dicatat";loadData()}catch(e:Exception){message=e.message?:"Gagal presensi"}}},onMaps={loc -> openMaps(loc)})
                        "Chat" -> ChatPage(chats, onSend={text -> scope.launch {try{withContext(Dispatchers.IO){api.sendMessage(text)};loadData()}catch(e:Exception){message=e.message?:"Pesan gagal dikirim"}}})
                        "Kartu Anggota" -> MemberCard(profile!!)
                        "Presensi QR" -> AttendancePage(schedules,profile!!)
                        "Dokumentasi" -> DocsPage(docs)
                        "Pengurus" -> AdminPage(profile!!, members,
                            onAdd={name,phone,mail,pw,role,group -> scope.launch { busy=true; try { withContext(Dispatchers.IO) { api.createMember(name,phone,mail,pw,role,group) }; message="Anggota berhasil ditambahkan"; loadData() } catch(e:Exception) { message=e.message ?: "Gagal menambahkan anggota" } finally { busy=false } } },
                            onUpdate={id,name,phone,role,active -> scope.launch { busy=true; try { withContext(Dispatchers.IO) { api.updateMember(id,name,phone,role,active) }; message="Data anggota diperbarui"; loadData() } catch(e:Exception) { message=e.message ?: "Gagal memperbarui anggota" } finally { busy=false } } },
                            onDelete={id -> scope.launch { busy=true; try { withContext(Dispatchers.IO) { api.deleteMember(id) }; message="Anggota berhasil dihapus"; loadData() } catch(e:Exception) { message=e.message ?: "Gagal menghapus anggota" } finally { busy=false } } })
                        else -> ProfilePage(profile!!,onCard={page="Kartu Anggota"},onLogout={api.logout();profile=null;page="Beranda";password=""})
                    }
                    if(busy) LinearProgressIndicator(Modifier.fillMaxWidth(),color=Maroon)
                }
            }
        }
    }
}

@Composable private fun TopAppBarPssab(page:String,name:String) { Row(Modifier.fillMaxWidth().background(DeepRed).padding(horizontal=16.dp, vertical=13.dp),verticalAlignment=Alignment.CenterVertically) { Text("PSSAB",color=Gold,fontWeight=FontWeight.Black,fontSize=22.sp); Spacer(Modifier.width(12.dp)); Column { Text(page,color=Color.White,fontWeight=FontWeight.Bold); Text("Horas, $name",color=Color.White.copy(alpha=.8f),fontSize=11.sp) } } }
@Composable private fun Panel(title:String,content:@Composable ColumnScope.()->Unit) { Card(Modifier.fillMaxWidth().padding(vertical=5.dp),colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(18.dp),elevation=CardDefaults.cardElevation(2.dp)) { Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) { Text(title,color=Maroon,fontWeight=FontWeight.Bold,fontSize=17.sp);content() } } }
@Composable private fun HomePage(profile:JSONObject,schedules:JSONArray,members:JSONArray,onNavigate:(String)->Unit,onRefresh:()->Unit,onMaps:(String)->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        Box(Modifier.fillMaxWidth().background(DeepRed,RoundedCornerShape(18.dp)).padding(18.dp)) { Column { Text("HORAS JALA GABE",color=Gold,fontSize=12.sp,fontWeight=FontWeight.Bold); Text("PUNGUAN SITUMORANG SIPITU AMA",color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Black);Text("SEKTOR TANJUNG UNCANG",color=Color.White);Text("Satu Hati, Satu Marga, Satu Doa",color=Gold,fontSize=13.sp) } }
        Panel("Horas, ${profile.optString("name","Anggota")}!") { Text("Selamat datang di aplikasi resmi PSSAB Tanjung Uncang.",color=Ink);Text("Total anggota aktif: ${(0 until members.length()).count { members.optJSONObject(it)?.optBoolean("active",true) == true }}",color=Ink); Button(onClick=onRefresh) { Text("Muat ulang data") } }
        val next=schedules.optJSONObject(0)
        Panel("Jadwal Ibadah Terdekat") { if(next==null) Text("Belum ada jadwal yang tersedia.") else { Text(next.optString("title"),fontWeight=FontWeight.Bold,color=Ink);Text("${next.optString("event_date")} · ${next.optString("event_time")}");Text("📍 ${next.optString("location")}");Button(onClick={onNavigate("Presensi QR")}) {Text("Daftar Hadir / QR")}; OutlinedButton(onClick={onNavigate("Ibadah")}){Text("Lihat semua jadwal")} } }
        val shortcuts=listOf("Anggota","Ibadah","Presensi QR","Chat","Dokumentasi","Kartu Anggota") + if(profile.optString("role")=="Admin") listOf("Pengurus") else emptyList()
        shortcuts.chunked(2).forEach { row -> Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { row.forEach { s -> Card(Modifier.weight(1f).clickable{onNavigate(s)},colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(14.dp)) { Column(Modifier.padding(14.dp)) { Text(when(s){"Anggota"->"👥";"Ibadah"->"📅";"Presensi QR"->"✅";"Chat"->"💬";"Dokumentasi"->"📷";else->"🪪"},fontSize=24.sp);Text(s,color=Maroon,fontWeight=FontWeight.Bold) } } } } }
    }
}
@Composable private fun MembersPage(members:JSONArray,onRefresh:()->Unit) { var search by remember { mutableStateOf("") }; Column { OutlinedTextField(search,{search=it},modifier=Modifier.fillMaxWidth(),label={Text("Cari anggota")},singleLine=true); Button(onClick=onRefresh) { Text("Muat ulang") }; LazyColumn { items((0 until members.length()).mapNotNull{members.optJSONObject(it)}.filter{it.optBoolean("active",true) && it.optString("name").contains(search,true)}) { m -> Panel(m.optString("name","Nama anggota")) { Text("ID: ${m.optString("member_id","Belum tersedia")}",color=Ink);Text("Jenis: ${m.optString("relationship","-")}",color=Ink);Text("Peran: ${m.optString("role","Anggota")}",color=Ink); Text("Status: ${if(m.optBoolean("active",true)) "Aktif" else "Nonaktif"}",color=Ink) } } } } }
@Composable private fun SchedulePage(schedules:JSONArray,profile:JSONObject,onAdd:(String,String,String,String)->Unit,onAttend:(String)->Unit,onMaps:(String)->Unit) {
    var add by remember { mutableStateOf(false) }; var title by remember{mutableStateOf("")};var date by remember{mutableStateOf("")};var time by remember{mutableStateOf("")};var loc by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize()) { Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()) { Text("Jadwal Ibadah",fontWeight=FontWeight.Bold,color=Maroon,fontSize=20.sp); if(profile.optString("role") in listOf("Admin","Ketua","Sekretaris")) TextButton(onClick={add=!add}){Text("+ Tambah")} }
        if(add) Panel("Jadwal baru") { OutlinedTextField(title,{title=it},label={Text("Nama kegiatan")},modifier=Modifier.fillMaxWidth());OutlinedTextField(date,{date=it},label={Text("Tanggal YYYY-MM-DD")},modifier=Modifier.fillMaxWidth());OutlinedTextField(time,{time=it},label={Text("Jam")},modifier=Modifier.fillMaxWidth());OutlinedTextField(loc,{loc=it},label={Text("Lokasi")},modifier=Modifier.fillMaxWidth());Button(onClick={if(title.isNotBlank()&&date.isNotBlank()&&loc.isNotBlank()){onAdd(title,date,time,loc);add=false}}){Text("Simpan jadwal")} }
        LazyColumn { items((0 until schedules.length()).mapNotNull{schedules.optJSONObject(it)}) { s -> Panel(s.optString("title","Ibadah")) { Text("📅 ${s.optString("event_date")} · ${s.optString("event_time")}",color=Ink);Text("📍 ${s.optString("location")}",color=Ink);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={onAttend(s.optString("id"))}){Text("Saya hadir")};OutlinedButton(onClick={onMaps(s.optString("location"))}){Text("Buka Maps")} } } } }
    }
}
@Composable private fun ChatPage(chats:JSONArray,onSend:(String)->Unit) { var draft by remember{mutableStateOf("")}; Column(Modifier.fillMaxSize()) { Text("Chat PSSAB",fontWeight=FontWeight.Bold,color=Maroon,fontSize=20.sp); LazyColumn(Modifier.weight(1f)) { items((0 until chats.length()).mapNotNull{chats.optJSONObject(it)}) { m -> Panel(m.optJSONObject("profiles")?.optString("name")?:"Anggota") { Text(m.optString("text"),color=Ink);Text(m.optString("created_at").take(16).replace('T',' '),fontSize=10.sp,color=Color.Gray) } } }; Row(verticalAlignment=Alignment.CenterVertically) { OutlinedTextField(draft,{draft=it},modifier=Modifier.weight(1f),label={Text("Tulis pesan")});IconButton(onClick={if(draft.isNotBlank()){onSend(draft.trim());draft=""}}){Icon(Icons.Default.Send,"Kirim",tint=Maroon)} } } }
@Composable private fun MemberCard(profile:JSONObject) { val id=profile.optString("member_id",profile.optString("id")); val qr=remember(id){qrBitmap("PSSAB|$id|${profile.optString("name")}")}; Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),horizontalAlignment=Alignment.CenterHorizontally) { Card(Modifier.fillMaxWidth().padding(top=12.dp),colors=CardDefaults.cardColors(containerColor=DeepRed),shape=RoundedCornerShape(20.dp)) { Column(Modifier.padding(18.dp),horizontalAlignment=Alignment.CenterHorizontally) { Text("PSSAB",color=Gold,fontSize=30.sp,fontWeight=FontWeight.Black);Text("KARTU ANGGOTA DIGITAL",color=Color.White,fontWeight=FontWeight.Bold);Spacer(Modifier.height(14.dp));Text(profile.optString("name"),color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold);Text("ID: $id",color=Gold);Text("Status: ${profile.optString("role","Anggota")}",color=Color.White);Text("Kategori: ${profile.optString("relationship","Anggota")}",color=Color.White);Spacer(Modifier.height(12.dp));Image(qr.asImageBitmap(),null,Modifier.size(190.dp).background(Color.White).padding(8.dp));Text("QR identitas anggota",color=Gold);Text("Satu Hati, Satu Marga, Satu Doa",color=Gold) } }; Text("Tunjukkan QR ini untuk membantu identifikasi anggota.",modifier=Modifier.padding(12.dp),color=Ink) } }
@Composable private fun AttendancePage(schedules:JSONArray,profile:JSONObject) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) { Panel("QR Kehadiran") { Text("Pilih jadwal di menu Ibadah untuk mencatat presensi. QR anggota ini bukan QR sesi presensi.",color=Ink);Text("Anggota: ${profile.optString("name")}");Text("ID: ${profile.optString("member_id",profile.optString("id"))}");Image(qrBitmap("PSSAB-MEMBER:${profile.optString("id")}").asImageBitmap(),null,Modifier.size(210.dp).align(Alignment.CenterHorizontally)) }; for(i in 0 until schedules.length()) { val s=schedules.optJSONObject(i)?:continue;Panel(s.optString("title")) {Text("${s.optString("event_date")} · ${s.optString("event_time")}");Text(s.optString("location"))} } } }
@Composable private fun DocsPage(docs:JSONArray) { Column { Text("Dokumentasi kegiatan",fontSize=20.sp,color=Maroon,fontWeight=FontWeight.Bold);Text("Foto dan metadata yang tersedia di Supabase.",color=Ink);LazyColumn { items((0 until docs.length()).mapNotNull{docs.optJSONObject(it)}) { d -> Panel(d.optString("caption","Dokumentasi")) { Text("Pengunggah: ${d.optJSONObject("profiles")?.optString("name")?:"Anggota"}",color=Ink);Text(d.optString("image_url"),color=Maroon,fontSize=11.sp) } } } } }
@Composable private fun ProfilePage(profile:JSONObject,onCard:()->Unit,onLogout:()->Unit) { Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),horizontalAlignment=Alignment.CenterHorizontally) { Spacer(Modifier.height(22.dp));Image(androidx.compose.ui.res.painterResource(R.drawable.pssab_logo),null,Modifier.size(100.dp));Text(profile.optString("name"),fontSize=23.sp,fontWeight=FontWeight.Bold,color=Ink);Text("ID: ${profile.optString("member_id",profile.optString("id"))} · ${profile.optString("relationship","Anggota")}",color=Ink);Text("Peran: ${profile.optString("role","Anggota")}",color=Maroon);Spacer(Modifier.height(12.dp));Panel("Pengaturan Profil") { Text("Informasi Pribadi · ${profile.optString("phone","Nomor HP belum diatur")}");Text("Email · ${profile.optString("email","Gunakan email login")}");Text("Notifikasi dan keamanan akun dikelola sesuai pengaturan layanan.");Button(onClick=onCard,modifier=Modifier.fillMaxWidth()){Text("Lihat Kartu Anggota")};OutlinedButton(onClick=onLogout,modifier=Modifier.fillMaxWidth()){Text("Keluar akun")} } } }
@Composable private fun AdminPage(profile: JSONObject, members: JSONArray,
    onAdd: (String,String,String,String,String,String)->Unit,
    onUpdate: (String,String,String,String,Boolean)->Unit,
    onDelete: (String)->Unit) {
    var showAdd by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("Anggota") }; var group by remember { mutableStateOf("01") }
    var query by remember { mutableStateOf("") }
    if (profile.optString("role") != "Admin") { Panel("Akses terbatas") { Text("Hanya Admin yang dapat mengelola anggota.", color=Ink) }; return }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween) {
            Text("Pengelolaan Anggota", color=Maroon, fontWeight=FontWeight.Bold, fontSize=19.sp)
            Button(onClick={showAdd=!showAdd}) { Text(if(showAdd) "Tutup" else "+ Anggota") }
        }
        OutlinedTextField(query,{query=it},label={Text("Cari nama anggota")},singleLine=true,modifier=Modifier.fillMaxWidth())
        if(showAdd) Panel("Tambah anggota baru") {
            OutlinedTextField(name,{name=it},label={Text("Nama lengkap")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(phone,{phone=it},label={Text("Nomor HP")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(email,{email=it},label={Text("Email login")},singleLine=true,modifier=Modifier.fillMaxWidth())
            OutlinedTextField(password,{password=it},label={Text("Password awal (min. 8 karakter)")},singleLine=true,visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
            Text("Kelompok Bona", color=Ink)
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { listOf("01","02","03","04").forEach { g -> FilterChip(selected=group==g,onClick={group=g},label={Text(mapOf("01" to "Bona","02" to "Boru","03" to "Bere","04" to "Iba Bere")[g]!!)}) } }
            Text("Peran", color=Ink)
            Row(horizontalArrangement=Arrangement.spacedBy(6.dp)) { listOf("Anggota","Ketua","Sekretaris","Bendahara","Admin").forEach { r -> FilterChip(selected=role==r,onClick={role=r},label={Text(r)}) } }
            Button(onClick={ if(name.isBlank()||email.isBlank()||password.length<8) Unit else { onAdd(name.trim(),phone.trim(),email.trim(),password,role,group); showAdd=false; name="";phone="";email="";password="" } },modifier=Modifier.fillMaxWidth(),enabled=name.isNotBlank()&&email.contains("@")&&password.length>=8) { Text("Buat akun anggota") }
            Text("Pembuatan akun memerlukan RPC admin_create_member dan kebijakan Supabase yang sesuai.",color=Color.Gray,fontSize=11.sp)
        }
        LazyColumn(Modifier.weight(1f)) {
            items((0 until members.length()).mapNotNull { members.optJSONObject(it) }.filter { it.optString("name").contains(query,true) }, key={it.optString("id")}) { m ->
                var edit by remember(m.optString("id")) { mutableStateOf(false) }
                var n by remember(m.optString("id")) { mutableStateOf(m.optString("name")) }
                var p by remember(m.optString("id")) { mutableStateOf(m.optString("phone")) }
                var r by remember(m.optString("id")) { mutableStateOf(m.optString("role","Anggota")) }
                var active by remember(m.optString("id")) { mutableStateOf(m.optBoolean("active",true)) }
                var confirmDelete by remember(m.optString("id")) { mutableStateOf(false) }
                if (confirmDelete) AlertDialog(onDismissRequest={confirmDelete=false}, title={Text("Hapus anggota?")}, text={Text("Anggota ${m.optString("name")} akan dihapus melalui fungsi backend. Tindakan ini mungkin tidak dapat dibatalkan.")}, confirmButton={TextButton(onClick={confirmDelete=false;onDelete(m.optString("id"))}){Text("Hapus",color=Maroon)}}, dismissButton={TextButton(onClick={confirmDelete=false}){Text("Batal")}})
                Panel(m.optString("name","Anggota")) {
                    Text("ID: ${m.optString("member_id",m.optString("id"))} · ${m.optString("relationship","-")}",color=Ink,fontSize=12.sp)
                    if(edit) {
                        OutlinedTextField(n,{n=it},label={Text("Nama")},singleLine=true,modifier=Modifier.fillMaxWidth())
                        OutlinedTextField(p,{p=it},label={Text("Nomor HP")},singleLine=true,modifier=Modifier.fillMaxWidth())
                        Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) { listOf("Anggota","Ketua","Sekretaris","Bendahara","Admin").forEach { v -> FilterChip(selected=r==v,onClick={r=v},label={Text(v,fontSize=10.sp)}) } }
                        Row(verticalAlignment=Alignment.CenterVertically) { Checkbox(active,{active=it}); Text("Anggota aktif") }
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Button(onClick={onUpdate(m.optString("id"),n,p,r,active);edit=false},enabled=n.isNotBlank()) { Text("Simpan") }; TextButton(onClick={edit=false}) { Text("Batal") } }
                    } else {
                        Text("Peran: $r · ${if(active) "Aktif" else "Nonaktif"}",color=Ink)
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick={edit=true}) { Text("Ubah") }; TextButton(onClick={confirmDelete=true}) { Text("Hapus",color=Maroon) } }
                    }
                }
            }
        }
    }
}

private fun qrBitmap(text:String):Bitmap { val matrix=QRCodeWriter().encode(text,BarcodeFormat.QR_CODE,420,420);return Bitmap.createBitmap(420,420,Bitmap.Config.ARGB_8888).also { b -> for(x in 0 until 420) for(y in 0 until 420) b.setPixel(x,y,if(matrix[x,y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE) } }
