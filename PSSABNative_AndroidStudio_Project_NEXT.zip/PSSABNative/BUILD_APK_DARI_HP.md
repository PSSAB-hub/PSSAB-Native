# Cara build APK hanya dengan HP Android (GitHub Actions)

Metode ini membangun APK di server GitHub, bukan di HP. HP hanya dipakai untuk mengunggah proyek dan mengambil hasil APK. Akun GitHub diperlukan; komputer tidak diperlukan.

## A. Buat repository GitHub
1. Buka https://github.com/new di Chrome HP dan masuk/daftar akun.
2. Buat repository baru bernama `PSSABNative`, pilih **Private** bila ingin kode tidak publik, lalu tekan **Create repository**.
3. Pada repository, pilih **Add file → Upload files**. Unggah file `PSSABNative_AndroidStudio_Project.zip` dari HP, lalu commit.
4. Pilih **Add file → Create new file**.
5. Pada nama file, isi persis `.github/workflows/build-apk.yml`.
6. Buka file `build-apk.yml` yang disertakan dalam proyek ini, salin seluruh isinya ke editor GitHub, lalu commit.

> Jika GitHub tidak mengizinkan pembuatan folder bertingkat lewat nama file, masukkan `.github/workflows/build-apk.yml` sekaligus sebagai nama file; GitHub biasanya membuat foldernya otomatis.

## B. Jalankan build
1. Buka tab **Actions** di repository.
2. Pilih workflow **Build PSSAB Android APK**.
3. Tekan **Run workflow → Run workflow**.
4. Tunggu sampai job selesai. Pertama kali mungkin memerlukan beberapa menit karena Gradle dan Android SDK diunduh.
5. Buka hasil run yang hijau, gulir ke **Artifacts**, lalu unduh `PSSAB-debug-APK`.
6. Ekstrak ZIP artifact dan temukan `app-debug.apk`. Buka file APK di HP untuk memasang; Android mungkin meminta izin **Install unknown apps** untuk browser atau File Manager yang digunakan.

## Jika build gagal
- Buka job yang merah dan salin pesan error terakhir untuk dianalisis.
- Error dependency/SDK dapat diperbaiki di workflow atau proyek; jangan anggap APK tersedia jika artifact tidak muncul.
- APK debug bukan rilis Play Store dan belum ditandatangani dengan kunci rilis.

## Catatan backend penting
- Proyek menggunakan URL dan publishable/anon key yang ditemukan di `config.js` aplikasi asli. Nilai ini memang ditujukan untuk klien, tetapi keberadaan nilai tersebut **tidak membuktikan** proyek Supabase masih aktif.
- Karena pemilik tidak punya akses dashboard Supabase, kita belum dapat memverifikasi schema, RLS, RPC admin, bucket, atau menguji login dan sinkronisasi data. Jika proyek Supabase tidak aktif atau kebijakannya menolak permintaan, APK dapat terpasang tetapi fitur online tidak berfungsi.
- Jangan pernah memasukkan Supabase `service_role` key ke APK.
- QR pada versi ini adalah QR identitas, bukan bukti presensi yang aman. Verifikasi presensi produksi perlu token sesi yang dibuat dan divalidasi server.
