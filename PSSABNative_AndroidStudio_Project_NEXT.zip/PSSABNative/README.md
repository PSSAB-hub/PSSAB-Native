# PSSAB Tanjung Uncang — Android Native (Kotlin + Jetpack Compose)

Native Android Studio project based on the supplied PSSAB web app and design. Brand assets are copied from the supplied archive. UI uses a maroon, gold, cream and white palette.

## Project and backend findings

- Supabase project URL and publishable/anon key were read from the supplied `config.js` and configured as build fields. These are client-side values; do not add a `service_role` key.
- Existing web app references these public tables: `profiles`, `schedules`, `messages`, `attendance`, and `documentation`.
- The web source also calls RPCs `admin_create_member`, `admin_update_member`, and `admin_delete_member`; native admin actions now call these same RPC names.
- Documentation storage bucket is named `documentation` in the web app.

## Native screens / operations implemented

- Email/password login and password recovery request using Supabase Auth REST endpoints.
- Home dashboard, active member directory/search, schedules, chat message list/send, digital member card with generated QR, attendance view, documentation metadata, profile and logout.
- Schedule creation and attendance upsert.
- Admin screen (visible to profile role `Admin`) for member creation, editing, active/inactive status and deletion via existing backend RPCs.
- Google Maps deep link for schedule locations.

## Open in Android Studio

1. Install Android Studio, JDK 17 and Android SDK Platform 35.
2. Extract the ZIP and open the `PSSABNative` folder containing `settings.gradle.kts`.
3. Allow Gradle Sync to download Android/Compose/OkHttp/ZXing dependencies (internet required).
4. Run on a device/emulator with internet access.
5. Build APK via **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Debug output is normally `app/build/outputs/apk/debug/app-debug.apk`.

## Backend requirements / caveats

This is an implementation-in-progress and has **not** been built or tested against a live Supabase project in this environment (Android SDK/Gradle and network access were unavailable). Confirm table column names and types, RLS policies, auth settings, and RPC function signatures against the live project. In particular:

- `profiles` should expose the columns used by the UI (`id`, `name`, `member_id`, `relationship`, `role`, `active`, `phone`, and any email field in use).
- `schedules` should expose `id`, `title`, `event_date`, `event_time`, `location`.
- `messages` should expose `id`, `text`, `created_at`, `sender_id` and the `profiles(name,role)` relation.
- `attendance` should support unique conflict target `(schedule_id, member_id)` and fields `schedule_id`, `member_id`, `status`.
- `documentation` should expose `id`, `image_url`, `caption`, `created_at`, `uploader_id` and a `profiles(name)` relation.
- Admin RPC signatures must exactly match the web app's named parameters. Member signup may be subject to email confirmation settings; if signup succeeds but the RPC fails, an auth user could be left without a profile and should be reconciled by an administrator.
- Admin UI visibility is not authorization. Enforce admin permissions in RLS/RPC server-side.

## Not yet complete / production checklist

- Camera-based QR scanner and server-validated, expiring attendance QR token. Current QR is an ID QR only and must not be treated as proof of attendance.
- Documentation photo picker/upload and image rendering (native screen currently displays metadata/URL).
- Profile edit, profile-photo upload, password-change flow.
- Realtime chat subscriptions and push notifications.
- Full build, lint, device tests and live Supabase integration tests.

Do not deploy until schema, policies, RPCs and the app have been tested with separate member/admin test accounts.

## Build APK using only an Android phone
See `BUILD_APK_DARI_HP.md`. A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`; it builds on GitHub-hosted Linux and uploads the debug APK as an artifact. This workflow has not yet been run, so compilation is not claimed successful.
